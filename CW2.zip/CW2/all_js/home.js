document.getElementById("head_login").addEventListener("click", function() {
    window.location.href = "log_sign.html";
});

document.getElementById("head_sign").addEventListener("click", function() {
    window.location.href = "log_sign.html";
});

document.getElementById("join_btn").addEventListener("click", function() {
    window.location.href = "log_sign.html";
})


document.addEventListener("DOMContentLoaded", function () {
    let isLoggedIn = localStorage.getItem("isLoggedIn");
    let savedEmail = localStorage.getItem("usermail");
    let changeButtons = document.getElementById("changeButtons");

    if (isLoggedIn === "true" && savedEmail) {
        let firstletter = savedEmail.charAt(0).toUpperCase();

        changeButtons.innerHTML =`<button class="logout_btn" onclick="logout()">Logout</button>
                                  <div class="pro_pic"> ${firstletter} </div>`;
    }
});

function logout() {
    localStorage.removeItem("isLoggedIn");
    window.location.href = "home.html";
}
